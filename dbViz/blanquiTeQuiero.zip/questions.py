def decision_boundary(args, net, loader, device):
    net.eval()
    correct = 0
    total = 0
    predicted_labels = []
    with torch.no_grad():
        for batch_idx, inputs in enumerate(loader):
            inputs = inputs.to(device)
            outputs = net(inputs)
            for output in outputs:
                predicted_labels.append(output)
            if args.dryrun:
                break
    return predicted_labels